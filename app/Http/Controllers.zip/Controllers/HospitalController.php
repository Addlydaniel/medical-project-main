<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Http;
class HospitalController extends Controller
{

    public function hospitalDashboard() {
       
         return view('hospital/hospitalDashboard');
     }
     public function hospitalList() {
       
        return view('hospital/hospitalList');
    }
    public function doctorList() {
       
        return view('hospital/doctorList');
    }
    public function addDoctor() {
       
        return view('hospital/addDoctor');
    }
   
   
    
}
